var fileNameArray=require('../public/img/book/path');


console.log(fileNameArray);