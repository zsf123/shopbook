// $(function() {
// 	var start = 8;
// 	var addnum = 8;
// 	var count = 1;
// 	var maxdown=45;
// 	document.onmousedown = function(e) {
// var down= e.clientY; //记录鼠标按下时距离顶部的距离
// maxdown=down>maxdown?down:maxdown;//记录最大的按下的距离
// 		document.onmousemove = function(e) {
// 			var move = e.clientY - maxdown; //移动的距离
// 			if (move > 200 && e.clientY > maxdown) { //朝增大的方向移动45px就查询数据库，增加8条数据
// 				$.get("/booklist/more", {
// 					start: start * count,
// 					addnum: addnum
// 				}).then(val => {
// 					var books = val.data;
// 					console.log(books);
// 					for (var i = 0; i < books.length; i++) {
// 						var html = "<div class='booklist'><a href='/bookdetail/id/" + books[i].id +
// 							"><img class='bookimg' src='" + books[i].imageurl + "' alt='书籍图片'>\
// 							<div><span class='ds fl'>商城价:" +
// 							books[i].price + "</span><span class='ds fr'>" + books[i].purchase_count +
// 							"人付款</span></div><p>" + books[i].bookname + "</p><p><span class='ps fl'>" + books[i].book_language +
// 							"</span>\
// 							<span class='fr ps'>" + books[i].keywords + "</span></p> <p > < span class = 'fl ps' > " +
// 							books[i].publisher + " <\
// 							/span><span class='fr ps'>" + books[i].publisher_area +
// 							"</span > </p></a> </div>"
// 					}
// 					document.getElementById("booklist").append(html);
// 					// $(this).find("#booklist").trigger("create");
// 					 $.parser.parse($("#booklist"));
// 				});
// 			}
// 			count++; //每次增加过后记一次数，改变下次查询开始的位置
// 		}
// 	}
//   document.onmouseup=function () {
	  // console.log("制定了")
    //鼠标抬起的时候,把移动事件干掉
    // document.onmousemove=null;
  // };
	// 	document.onmousemove=function(e){
	// 		console.log(e.clientX+"   "+e.clientY+"----1");
	// 		console.log(e.pageX+"   "+e.pageY+"----2");
	// 	}

// });
