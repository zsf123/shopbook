const url="http://localhost:3000/";
// 购物车页面逻辑
window.onload = function() {
	var allCheckBox = document.getElementsByName("allcheckbox"); //全复选框
	var itemCheckBox = document.getElementsByName("itemcheckbox"); //子复选框
	var subtotal = document.getElementsByName("subtotal"); //所有的小计
	var accountbtn = document.getElementsByName("account"); // 结算按钮对象
	var getnum = document.getElementsByName("getnum"); //所有购物项的商品件数
	var addnum = document.getElementsByName("addnum"); //获得所有的加项
	var delnum = document.getElementsByName("delnum"); //获得所有的减项
	var delbtnitem = document.getElementsByName("delitem"); //获得所有的单个的删除按钮
	// 两个结算输入框对象
	var totalprice1 = document.getElementById("totalprice1");
	var totalprice2 = document.getElementById("totalprice2");

	//获得总件数对象
	var totalcount = document.getElementById("totalcount");

	// 全选和全不选================================================================================
	// 全选和全不选点击事件
	for (var i = 0; i < allCheckBox.length; i++) {
		// 为每个全选按钮点击事件
		allCheckBox[i].onclick = function() {
			var that = this;
			var totalpricenum = 0;
			var totalcountnum = 0;
			// 勾选逻辑
			for (var i = 0; i < itemCheckBox.length; i++) {
				itemCheckBox[i].checked = this.checked;
			}
			// 全选按钮选中逻辑
			if (that.checked) {
				// 一个全选选中，两个全选都选中
				for (var i = 0; i < allCheckBox.length; i++) {
					allCheckBox[i].checked = that.checked;
				}
				// 计算总价格
				for (var i = 0; i < subtotal.length; i++) {
					totalpricenum = (parseFloat(totalpricenum) + parseFloat(subtotal[i].value)).toFixed(2);
				}
				// 为结算按钮添加样式
				for (var i = 0; i < accountbtn.length; i++) {
					accountbtn[i].style.backgroundColor = "#F52B00";
					accountbtn[i].style.color = "#000";
				}
				totalcount.value = itemCheckBox.length / 2; //总件数的个数是所有复选框个数的一半，因为这里获得的复选框有重复的
			} else {
				// 全选按钮未选中逻辑

				// 一个全选选中，两个全选都选中
				for (var i = 0; i < allCheckBox.length; i++) {
					allCheckBox[i].checked = that.checked;
					totalpricenum = 0; //总价格
				}
				// 为结算按钮添加样式
				for (var i = 0; i < accountbtn.length; i++) {
					accountbtn[i].style.backgroundColor = "#b0b0b0";
					accountbtn[i].style.color = "#fff";
				}
				totalcount.value = 0;
			}

			// 同步两个总价格
			totalprice1.value = totalpricenum;
			totalprice2.value = totalpricenum;


		}
	}
	// ======================================================================================
	// 只要有一个复选框处于选中状态，那么结算按钮样式就会改变
	function changeColor() {
		var flag = false; //假设所有的复选框都没被选中
		for (var i = 0; i < itemCheckBox.length; i++) {
			if (itemCheckBox[i].checked) {
				flag = true; //有一个选中
				break;
			}
		}
		if (flag) {
			// 为两个结算按钮添加样式
			for (var i = 0; i < accountbtn.length; i++) {
				accountbtn[i].style.backgroundColor = "#F52B00";
				accountbtn[i].style.color = "#000";
			}
		} else {
			// 为两个结算按钮添加样式
			for (var i = 0; i < accountbtn.length; i++) {
				accountbtn[i].style.backgroundColor = "#b0b0b0";
				accountbtn[i].style.color = "#fff";
			}
		}
	}

	// 子复选框是否全选和（相同子复选框都勾选)
	for (var i = 0; i < itemCheckBox.length; i++) {
		// 为每个子复选框添加点击事件
		itemCheckBox[i].onclick = function() {
			// 获取当前选中复选框的索引
			var index = this.getAttribute("index");
			// 找到相同索引的复选框选中
			for (var j = 0; j < itemCheckBox.length; j++) {
				if (itemCheckBox[j].getAttribute("index") == index) {
					itemCheckBox[j].checked = this.checked;
				}
			}
			// 默认当前选中的情况下就是全选
			var flag = true;
			//------------------------------------------
			for (var j = 0; j < itemCheckBox.length; j++) {
				// 选择一个复选框的时候判断是否此时所有的复选框的状态都是被选中，如果都被选中则全选要被选中
				if (!itemCheckBox[j].checked) {
					//没选中就进来了
					flag = false;
					break;
				}

			}

			//----------------------------------------
			//全选的这个复选框的状态就是flag这个变量的值
			for (var i = 0; i < allCheckBox.length; i++) {
				allCheckBox[i].checked = flag;
			}

			// 如果当前子复选框选中状态
			// 子复选框选中件数和总价格计算逻辑

			if (this.checked) {
				// 更新总价格
				// 当前的总价格加上选中的复选框的小计（小计需要查询数据库）
				$.get(url+"shopcar/index/" + index).then(val => {
					total = (parseFloat(totalprice1.value) + parseFloat(val.smallprice)).toFixed(2);
					console.log("xiaoji" + val.smallprice + "totalprice1" + parseFloat(totalprice1.value) + "-----" + total);
					// 为两个总价格设置同样的值
					totalprice1.value = total;
					totalprice2.value = total;
				})

				// 更新总件数  总件数是按照购物项计算的，不是按照购物项数量计算的
				totalcount.value = parseInt(totalcount.value) + 1;

			} else {
				// 复选框未选中状态
				// 更新总价格
				// 当前的总价格减去选中的复选框的小计（小计需要查询数据库）

				$.get(url+"shopcar/index/" + index).then(val => {
					total = (parseFloat(totalprice1.value) - parseFloat(val.smallprice)).toFixed(2);
					// 为两个总价格设置同样的值
					totalprice1.value = total;
					totalprice2.value = total;
				})
				// 更新总件数
				totalcount.value = parseInt(totalcount.value) - 1;
			}
			// 改变结算按钮样式
			changeColor();

		}
	}

	// ----------------------------------------------------------------------------
	// 为每个购物项添加增加和减少单击事件，鼠标移入，鼠标移出事件----------------------------------------------------------
	var num; //减少是需要保存数量
	for (var i = 0; i < addnum.length; i++) {
		// 增加：当前数量增加，并且小计也改变，如果从1变到2又要改变减少的框框样式，并且这些改变，数量要进行入库
		addnum[i].onclick = function() {
			// 获取当前点击按钮的索引
			var index = this.getAttribute("index");

			// 修改数量入库操作,修改页面数量和小计，减号样式
			for (var j = 0; j < getnum.length; j++) {
				// 找到当前选中的加号的数量对象
				if (getnum[j].getAttribute("index") == index) {
					// 修改页面数量
					getnum[j].value = parseInt(getnum[j].value) + 1;
					num = getnum[j].value;

					// 修改页面小计(当前数量*单价)
					for (var j = 0; j < subtotal.length; j++) {
						if (subtotal[j].getAttribute("index") == index) {
							subtotal[j].value = (parseInt(num) * parseFloat(this.getAttribute("itemprice").substring(1))).toFixed(
								2);
							break;
						}
					}
					// 进行持久化操作
					$.get("/updateShoppingCartCount", {
						count: num,
						id: this.getAttribute("shoppingcartid")
					}).then(val => {
						console.log(val.msg);
					});
					// 同步更改但要刷新页面，没办法保持复选框的勾选状态
					// window.location.href="/updateShoppingCartCount?count="+getnum[j].value+"&id="+this.getAttribute("shoppingcartid");

					// 每次点击添加按钮，如果是从1->2需要修改减少按钮的状态
					if (num >= 2) {
						for (var j = 0; j < delnum.length; j++) {
							// 找到当前选中增加按钮对应的减少按钮
							if (delnum[j].getAttribute("index") == index) {
								delnum[j].value = "-";
								delnum[j].disabled = false;
								delnum[j].style.border = "1px solid #ddd";
								delnum[j].style.color = "black";
								break;
							}
						}
					}

					break;
				}

			}


			// 更新总价格。（购物项复选框是选中状态，更新总价格）
			for (var i = 0; i < itemCheckBox.length; i++) {
				// 获取当前选中复选框的索引
				if (index == itemCheckBox[i].getAttribute("index")) {
					if (itemCheckBox[i].checked) {
						// 当前的总价格加上选中的复选框的单价
						totalprice1.value = (parseFloat(totalprice1.value) + parseFloat(this.getAttribute("itemprice").substring(1))).toFixed(
							2);
						// 为两个总价格设置同样的值
						totalprice2.value = totalprice1.value;
						break;
					}
				}
			}



		}

		// 减少都在添加按钮的循环里面:======================================================================================================
		delnum[i].onclick = function() {
			// 获取当前点击按钮的索引
			var index = this.getAttribute("index");
			// 进行修改页面数量和小计，数据库入库操作
			for (var j = 0; j < getnum.length; j++) { //找到当前的数量进行一系列跟数量有关联的操作
				// 找到当前选中的加号的数量对象
				if (getnum[j].getAttribute("index") == index) {
					getnum[j].value = parseInt(getnum[j].value) - 1;
					num = getnum[j].value;
					if (num <= 1) {
						// 修改页面数量和小计
						getnum[j].value = 1;
						for (var j = 0; j < subtotal.length; j++) {
							if (subtotal[j].getAttribute("index") == index) {
								// 设置小计（小计设置成单价）
								subtotal[j].value = parseFloat(this.getAttribute("itemprice").substring(1)).toFixed(2);
								break;
							}
						}

					} else {
						//数量大于1的小计情况
						// 设置小计（数量乘以当前小计）
						for (var j = 0; j < subtotal.length; j++) {
							if (subtotal[j].getAttribute("index") == index) {
								subtotal[j].value = (parseInt(num) * parseFloat(this.getAttribute("itemprice").substring(
									1))).toFixed(2);
								break;
							}
						}

					}
					// 进行持久化操作
					$.get("/updateShoppingCartCount", {
						count: num,
						id: this.getAttribute("shoppingcartid")
					}).then(val => {
						console.log(val.msg);
					});
					// 同步更改但要刷新页面，没办法保持复选框的勾选状态
					// window.location.href="/updateShoppingCartCount?count="+getnum[j].value+"&id="+this.getAttribute("shoppingcartid");

					// 修改样式
					if (num <= 1) {
						// 设置当前减少按钮的样式
						this.value = "";
						this.disabled = true;
						this.style.border = "1px solid #ddd";
					} else {
						// 数量大于1，设置当前减少按钮的样式
						this.value = "-";
						this.disabled = false;
						this.style.border = "1px solid #f00";
						this.style.color = "red";
					}
					break;
				}


			}

			// 更新总价格。（购物项复选框是选中状态，更新总价格）（为什么不放上面，因为上面的数量和总价格没关联）
			for (var i = 0; i < itemCheckBox.length; i++) {
				if (index == itemCheckBox[i].getAttribute("index")) {
					if (itemCheckBox[i].checked) {
						// 当前的总价格减去上选中的复选框的单价（小计需要查询数据库）
						totalprice1.value = (parseFloat(totalprice1.value) - parseFloat(this.getAttribute("itemprice").substring(1)))
							.toFixed(2);
						// 为两个总价格设置同样的值
						totalprice2.value = totalprice1.value;
						break;
					}
				}
			}

		}
		// ================================================================================================================
		// 鼠标移入事件
		addnum[i].onmouseover = function() {
			this.className = "fl onmouseover";
			this.style.border = "1px solid #f00"; //边框没办法通过className设置
		}
		// 鼠标移出事件
		addnum[i].onmouseout = function() {
			this.className = "fl onmouseout";
			this.style.border = "1px solid #ddd";
		}
		// 鼠标移入事件
		delnum[i].onmouseover = function() {
			var flag = false;
			// 如果一开始数字为1，则不改变样式
			for (var j = 0; j < getnum.length; j++) {
				if (getnum[j].getAttribute("index") == this.getAttribute("index")) {
					// 找到当前的计数
					if (getnum[j].value == 1) {
						this.className = "fl";
						this.style.cursor = "default";
						flag = true;
					}
				}
			}
			if (!flag) {
				this.style.border = "1px solid #f00";
				this.style.color = "red";
				this.style.cursor = "pointer";
			}
		}
		// 鼠标移出事件
		delnum[i].onmouseout = function() {
			this.style.border = "1px solid #ddd";
			this.style.color = "black";
		}
	}

	//======================================================================================
	// 删除单个购物项===============================================================================================
	
	var mask = document.getElementById("mask1");
	var modal = document.getElementById("modal");
	var displaytext = document.getElementById("displaytext");
	
	for (var i = 0; i < delbtnitem.length; i++) {
		// 为每一个删除按钮添加点击事件
		delbtnitem[i].onclick = function() {
			var that = this;
			mask.style.display = "block";
// 			mask.style.position = "fixed";
// 			mask.style.width = "100%";
// 			mask.style.height = "100%";
// 			mask.style.background = "rgba(0, 0, 0, 0.3)";
// 			mask.style.zIndex = "2200000";
			displaytext.innerHTML =
				`<div>删除宝贝</div><div>确定要删除该宝贝吗?</div><div><a  id="conform">确定</a><a id="cancle">关闭</a></div>`;
			modal.style.display = "block";
			var conform = document.getElementById("conform");
			var cancle = document.getElementById("cancle");
			if (conform) {
				conform.onclick = function() {
					var id = that.getAttribute("shoppingcartid");
					$.get("/shopcar/del/id/" + id).then(val => {
						window.location.href = "/shopcar";
					})
				}
			}
			if (cancle) {
				cancle.onclick = function() {
					mask.style.display = "none";
					modal.style.display = "none";
					return false;
				}
			}
		}

	}

	// 删除全部购物项
	var delall = document.getElementById("delall");
	var allshopcaridlist = [];
	delall.onclick = function() {
		var flag = false;
		allshopcaridlist = []; //初始化为空
		// 判断复选框是否有选中的
		for (var j = 0; j < itemCheckBox.length; j++) {
			if (itemCheckBox[j].checked) {
				var id = itemCheckBox[j].getAttribute("shoppingcartid");
				if (id != null) { //因为我只在下面的复选框绑定了属性id
					allshopcaridlist.push(id);
				}
				// 保存所有选中的复选框对象的购物项id
				flag = true;
			}
		}
		console.log(allshopcaridlist);
		// 全部未选中
		if (!flag) {
			// 显示模态框
			mask.style.display = "block";
			modal.style.display = "block";
			displaytext.innerHTML = "您还没有选中宝贝";
			mask.style.position = "fixed";
			mask.style.width = "100%";
			mask.style.height = "100%";
			mask.style.background = "rgba(0, 0, 0, 0.3)";
			mask.style.zIndex = "2200000";
		} else {
			// 有选中的,批量删除
			mask.style.display = "block";
			modal.style.display = "block";
			displaytext.innerHTML =
				'<div>删除宝贝</div><div>确定要删除这些宝贝吗?</div><div><a " id="conform">确定</a><a  id="cancle">关闭</a></div>';
			mask.style.position = "fixed";
			mask.style.width = "100%";
			mask.style.height = "100%";
			mask.style.background = "rgba(0, 0, 0, 0.3)";
			mask.style.zIndex = "2200000";
			if (conform) {
				conform.onclick = function() {
					// 持久化数据库
					$.ajax({
						type: "post",
						url: "/shopcar/delall",
						dataType: "json",
						contentType: "application/json",
						data: JSON.stringify({
							idlist: allshopcaridlist
						}),
						success: function(data) {
							window.location.href = "/shopcar";
						}
					})
					mask.style.display = "none";
					modal.style.display = "none";
					return false;
				}
			}
			if (cancle) {
				cancle.onclick = function() {
					mask.style.display = "none";
					modal.style.display = "none";
					return false;
				}
			}
		}
	}

	// 点击关闭模态框
	document.getElementById("cross").onclick = function() {
		mask.style.display = "none";
		modal.style.display = "none";
	}

}
