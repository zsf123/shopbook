window.onload = function() {
	//页面加载设置导航条 显示内容
	var ul = document.getElementById("header-left");
	// var lis=ul.getElementsByTagName("li");//找到ul的孩子元素
	while (ul.hasChildNodes()) //当div下还存在子节点时 循环继续
	{
		ul.removeChild(ul.firstChild);
	}
	var leftli = document.createElement('li'); //创建一个新的里
	leftli.className = "leftli";
	leftli.innerText = "欢迎注册";
	ul.appendChild(leftli);

	// ---------------------------
	// 设置导航条右边
	var ele = document.getElementById("header-right");
	while (ele.hasChildNodes()) //当div下还存在子节点时 循环继续
	{
		ele.removeChild(ele.firstChild);
	}
	ele.className = "rightdiv";
	var rightli = document.createElement('h3');
	rightli.className = "rightli";
	rightli.innerText = "已有账号 ? ";
	ele.appendChild(rightli);
	var righta = document.createElement('a');
	righta.href = "/login";
	righta.innerHTML = "请登录";
	righta.className = "righta";
	ele.appendChild(righta);



	//点击账户表单框，去除提示文字
	var ele = document.getElementById("username");
	ele.onblur=function(){//失去焦点的时候，判断输入框有值（不做任何改变），无值（显示提示）
	if(ele.value==''){
		ele.placeholder="请输入用户名";
	}
		
	}
	ele.onfocus = function() {//获得焦点的时候value为空时清除输入框的内容，value="不空时不做任何改变"
	if(ele.value==''){
		// ele.value = '';
		ele.placeholder = '';
	}
			
	}
	
	
}
