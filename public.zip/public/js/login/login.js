window.onload=function(){
	document.getElementById("username").onfocus=function(){
		this.value='';
		this.setAttribute("placeholder","");
	}
	document.getElementById("password").onfocus=function(){
		this.value='';
		 this.setAttribute("placeholder","");
	}
	
	document.getElementById("username").onblur=function(){
		if(!this.value){
			this.value="请输入用户名";
		}
	}
	document.getElementById("password").onblur=function(){
		if(!this.value){
			 this.setAttribute("placeholder","请输入密码");
		}
	}
		
}