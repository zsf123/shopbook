$(function() {
	function search() {
		// e.preventDefault();
		var param = $.trim($("#searchparam").val());
		if (param == null || param == '') {
			alert("查询参数不能为空");
		} else if (param != null && param != '') {
			// Ajax不能获取对象，只能获取字符串比如JSON
			$.ajax({
				type: "GET",
				url: "/searchBookList",
				data: {
					param: param
				},
				dataType: "json",
				success: function(data) {
					var res = data;
					if (res.code == 'success') {
						window.location.href = "http://localhost:3000/" + res.content;
					}
				}
			});
		}
	}
	$("#search").on('click', search); //写参数是为了以防开启页面就加载

	// 	$("#searchparam").on("keydown", function(e) {
	// 		// 如果按下的是enter事件，执行查询方法
	// 		if (e.keyCode == 13) {
	// 			search();
	// 		}
	// 	});

	function my$(id) {
		return document.getElementById(id);
	}

	// 设置标签文本内容
	function setInnerText(element, text) {
		if (typeof element.textContent == "undefined") {
			element.innerText = text;
		} else {
			element.textContent = text;
		}
	}
	// 获得标签文本内容
	function getInnerText(element) {
		if (typeof(element.textContent) == "undefined") {
			return element.innerText;
		} else {
			return element.textContent;
		}
	}
	// 为搜索框注册键盘抬起事件
	my$("searchparam").onkeyup = function(e) {
		that = this;
		// 关键词
		var keyWords = [];
		
		// 装每个ｐ对象
		// var plist=[];
		$.get("http://localhost:3000/getKeyWords").then(function(data) {
			for (var i = 0; i < data.length; i++) {
				keyWords.push(data[i]); //将返回的所有书名赋值到关键字中
			}
			//每一次的键盘抬起都判断页面中有没有这个div
			if (my$("dv")) {
				//删除一次
				my$("search-button").removeChild(my$("dv"));
			}
			//获取文本框输入的内容
			var text = that.value;
			console.log(text);
			//临时数组--空数组------->存放对应上的数据
			var tempArr = [];
			//把文本框输入的内容和数组中的每个数据对比
			for (var i = 0; i < 1000; i++) {
				//是否是最开始出现的
				if (keyWords[i].indexOf(text) == 0) {
					tempArr.push(keyWords[i]); //追加
				}
			}
			//如果文本框是空的,临时数组是空的,不用创建div
			if (that.value.length == 0 || tempArr.length == 0) {
				//如果页面中有这个div,删除这个div
				if (my$("dv")) {
					my$("search-button").removeChild(my$("dv"));
				}
				return;
			}
			//创建div,把div加入id为box的div中
			var dvObj = document.createElement("div");
			my$("search-button").appendChild(dvObj);
			dvObj.id = "dv";
			dvObj.style.backgroundColor = "white";
			dvObj.style.marginTop = "35px";
			dvObj.style.width = "325px";
			dvObj.style.border = "1px solid #f4f4f4";
			dvObj.style.borderTop = "none";
			dvObj.style.borderLeft = "none";
			dvObj.style.borderRadius = "0 0 10px 10px";
			//循环遍历临时数组,创建对应的p标签
			for (var i = 0; i < tempArr.length; i++) {
				//创建p标签
				var pObj = document.createElement("p");
				
				//把p加到div中
				dvObj.appendChild(pObj);
				setInnerText(pObj, tempArr[i]);
				pObj.style.margin = 0;
				pObj.style.padding = 0;
				pObj.style.cursor = "pointer";
				pObj.style.marginTop = "5px";
				pObj.style.marginLeft = "5px";
				// plist.push(pObj);
				
				//鼠标进入
				pObj.onmouseover = function() {
					this.style.backgroundColor = "#f4f4f4";
					var value = getInnerText(this);
					my$("searchparam").value = value;
				};
				//鼠标离开
				pObj.onmouseout = function() {
					this.style.backgroundColor = "";
				};
					}
			});
// 			for(var i=0;i<plist.length;i++){
// 				// 为每个p注册单击和双击事件
// 				plist[i].onclick=function(){
// 					alert("单机")
// 					var value = getInnerText(this);
// 					my$("searchparam").value = value;
// 				};
// 			}

	}
	// 为搜索框绑定失去焦点事件
	my$("searchparam").onblur = function(e) {
		if (my$("dv")) {
			my$("search-button").removeChild(my$("dv"));
		}
	}
	// -----------------------------------------------------------------------------------------



	//当屏幕滚动的时候固定搜索栏
	var searchContainer = $(".public-logo"); //得到搜索框容器
	var logo = $("#logo"); //得到logo图片对象
	var search = $("#search-button"); //得到搜索框样式
	var win = $(window); //得到窗口对象
	var sc = $(document); //得到document文档对象。
	win.scroll(function() {
		if (sc.scrollTop() >= 150) {
			searchContainer.addClass("public-logo-fixed");
			logo.addClass("search-logo-fixed");
			search.addClass("public-search-btn-search");
		} else {
			searchContainer.removeClass("public-logo-fixed");
			logo.removeClass("search-logo-fixed");
			search.removeClass("public-search-btn-search");
		}
	})
});
