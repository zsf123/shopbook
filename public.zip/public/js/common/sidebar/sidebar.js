// 侧边栏
$(function(){
	var sidebar = $("#sidebar");
	var win = $(window); //得到窗口对象
	var sc = $(document); //得到document文档对象。
	win.scroll(function() {
		console.log("怎么了");
		if (sc.scrollTop() >= 50) {
			sidebar.css("display", "block");
		} else {
			sidebar.css("display", "none");
		}
	})
	// 回到顶部
	$("#gototop").click(function() {
		$('body,html').animate({
			scrollTop: 0
		}, 500);
	})
	// 回到底部
	var bodyHeight = sc.height();
	$("#gotofooter").click(function() {
		$("#foot").css('display', "none");
		$('body,html').animate({
			scrollTop: bodyHeight
		}, 500);
	});
})