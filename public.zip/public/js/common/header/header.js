// 头部js
$(function() {
	//顶部购物车逻辑----------------------------------------------------------------
	// 为购物车空时为导航添加鼠标移入事件
	$("#shop").mouseover(function() {
		$("#shopcar").prop("src", "/public/icon/blackshopcar.png");
	})
	// 购物车鼠标移出事件
	$("#shop").mouseout(function() {
		$("#shopcar").prop("src", "/public/icon/shopcar.png");
	})

	// 首页一加载，就判断用户是否登录，如果登录，显示购物车数量，未登录不显示
	$.ajax({
			type: "get",
			url: "/userflag", //判断用户是否登录
			dataType: "json",
			success: function(data) {
				result = data;
				if (data.code == 200) {
					$.ajax({
						type: "get",
						url: "/shoppingCarCount",
						dataType: "json",
						success: function(data) {
							if (data.totalCount == 0) {
								$("#end").css("display", "none");
							} else {
								$("#end").val(data.totalCount);
								$("#end").css("backgroundColor", "red");
								$("#end").css("color", "black");
							}
						}
					});
				} else { //用户未登录
					// 不显示购物车数量按钮
					$("#end").css("display", "none");
				}
			}
	});

//----------------------------------------------------------
//顶部导航显示hot门
// 页面一加载就查询哪些是热门的
// 获得所有li标签内容是文学，综合性图书的标签
// var elelist = document.getElementsByTagName("a");
var elelist = $("#geta a");
for (var i = 0; i < elelist.length; i++) {
	if (elelist[i].innerHTML == '文学' || elelist[i].innerHTML == '综合性图书' || elelist[i].innerHTML == '语言、文学') {
		var iele = $("<i></i>");
		iele.addClass("hot");
		// var img=$("<img src='/public/img/hot.gif'/>");
		// img.addClass("hot");
		var ele = $(elelist[i]);
		ele.append(iele);
	}
}
});
